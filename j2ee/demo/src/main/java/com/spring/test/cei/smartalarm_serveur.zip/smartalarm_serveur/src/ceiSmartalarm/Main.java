package ceiSmartalarm;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

import org.json.JSONException;

public class Main {

	public static void main(String[] args) throws IOException, JSONException {

		//adresee where Netatmo will send the information
		int port = 8080;
		String webHook = "http://43.ip-51-255-41.eu:"+port + "/api/netatmo";

		ConnectionNetatmo camera = new ConnectionNetatmo();
		camera.dropWebhook();
		camera.addWebhook(webHook);


		ServerSocket server = new ServerSocket(port);  
		Log.info("Server started, listening on port : "+ port);
		//System.out.println("Server started, listening on port : "+ port);

		Socket client = null;  
		boolean serverOn = true;  
		
		//listen to thr port
		while(serverOn){  
			client = server.accept();  
			Log.info(client.getInetAddress() + ":" +client.getPort() + "New connection accepted." );
			//System.out.println("New connection accepted : " + client.getInetAddress() + ":" +client.getPort());  
			
			//A new thread to process the request
			new Thread(new Server(client)).start();  
		}  
		server.close();
	}

}
